import React from 'react';
import { render } from 'react-dom';
import Example from './example';

render(<Example />, document.querySelector('#content'));
